'use strict';

/**
 *  plate controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::plate.plate');
