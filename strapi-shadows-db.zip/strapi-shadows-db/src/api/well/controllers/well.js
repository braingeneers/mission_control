'use strict';

/**
 *  well controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::well.well');
