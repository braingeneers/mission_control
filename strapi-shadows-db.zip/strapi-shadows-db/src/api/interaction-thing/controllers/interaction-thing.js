'use strict';

/**
 *  interaction-thing controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::interaction-thing.interaction-thing');
