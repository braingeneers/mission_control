'use strict';

/**
 * interaction-thing service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::interaction-thing.interaction-thing');
