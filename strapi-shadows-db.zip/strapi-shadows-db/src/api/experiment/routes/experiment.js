'use strict';

/**
 * experiment router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::experiment.experiment');
