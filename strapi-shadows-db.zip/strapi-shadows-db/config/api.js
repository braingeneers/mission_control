module.exports = {
  rest: {
    defaultLimit: 100,
    maxLimit: 100,
    withCount: true,
  },
};
